﻿namespace DataAccess.Abstract
{
    public interface IWordToExcludeDal
    {
        bool CheckWord(string word);
    }
}