﻿using Core.Entities;

namespace Entities.Dto
{
    public class website : IDto
    {
        public string Url { get; set; }
    }
}