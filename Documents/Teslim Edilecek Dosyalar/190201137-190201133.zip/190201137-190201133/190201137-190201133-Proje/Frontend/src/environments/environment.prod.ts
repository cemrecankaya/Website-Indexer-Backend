export const environment = {
  production: true,
  apiUrl: "https://yazlab21.somee.com/api/"
};
