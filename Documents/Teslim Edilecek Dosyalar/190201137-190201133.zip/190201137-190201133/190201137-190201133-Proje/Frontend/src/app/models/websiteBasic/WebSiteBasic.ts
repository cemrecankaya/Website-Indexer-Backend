export interface WebSiteBasic{
    url:string;
}