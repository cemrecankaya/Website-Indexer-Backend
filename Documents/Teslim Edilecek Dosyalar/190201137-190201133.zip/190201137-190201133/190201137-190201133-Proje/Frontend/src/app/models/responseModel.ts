export interface ResponseModel{
    message:String;
    success:boolean;
}