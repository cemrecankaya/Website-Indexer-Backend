export interface Keyword {
    word:string;
    frequency:Number;
    score:Number;
}