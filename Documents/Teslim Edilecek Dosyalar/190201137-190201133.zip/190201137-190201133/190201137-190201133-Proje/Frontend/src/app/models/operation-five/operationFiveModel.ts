import { OperationFourModel } from "../operation-four/operationFourModel";

export interface OperationFiveModel extends OperationFourModel{
    
}
