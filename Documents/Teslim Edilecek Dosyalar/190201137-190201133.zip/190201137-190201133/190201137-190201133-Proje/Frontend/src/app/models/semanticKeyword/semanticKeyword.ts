import { Keyword } from "../keyword/keywordModel";

export interface SemanticKeyword{
    word:String,
    similarWords:Keyword[]

}

