export interface FrequanceModel{
    word:String;
    frequency:Number;
}