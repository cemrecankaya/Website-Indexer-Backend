import { FrequanceModel } from "../frequance/frequanceModel";

export interface OperationOneModel{
    url:string;
    title:string;
    words:FrequanceModel[];
}